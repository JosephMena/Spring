package org.zer0.pocs.spring.rxjavamongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RxjavaMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RxjavaMongodbApplication.class, args);
	}
}
